package com.example.proyectofragmentos2

data class Alumno(val nombre: String)